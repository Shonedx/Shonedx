#include	"sys.h"
#include	"delay.h"
#include	"usart.h"
#include	"led.h"
#include	"lcd.h"
#include	"can.h"
#include	"pid.h"
#include	"timer.h"
#include	"RemoteControl_Init.h"
#include	"RC_Command.h"
#include	"IMU.h"
#include	"IWDG.h"
#include	"string.h"
#include	"key.h"
#include	"ges_cal.h"
#include	"main_params.h"

#define LPS left_push_stick 	//�����Ƹ�
#define RPS right_push_stick 	//�����Ƹ�

