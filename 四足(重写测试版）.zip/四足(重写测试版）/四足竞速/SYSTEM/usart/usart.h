#ifndef __USART_H
#define __USART_H

// USART��غ궨��
#define EN_USART1_RX 1 // �Ƿ�����USART1��RX�жϡ�
// ���ݽṹ����
typedef struct {
    float roll;
    float pitch;
    float yaw;
	
	float init_roll;
	float init_pitch;
	float init_yaw;
} Euler_t;
typedef struct {
    int16_t Angle[3];
} stcAngle_t;

// USART��غ�������
void uart_init(uint32_t bound);
void uart3_init(uint32_t bound);
void USART1_IRQHandler(void);
void USART3_IRQHandler(void);
void UART1_Put_Char(unsigned char DataToSend);
void UART1_Put_String(unsigned char *Str);
void CopeSerial3Data(unsigned char ucData);

#endif // __USART_H
